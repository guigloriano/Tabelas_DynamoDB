# Lendo dados ambientais de uma tabela no DynamoDB e criando CSV com estes dados

## Começando

```
npm i
```

Após isso, crie um arquivo config.js com suas credenciais de acesso. Então, execute:

```
node writeCSVEnvironmental.js
```

Para executar mais vezes, rode apenas o segundo comando.
