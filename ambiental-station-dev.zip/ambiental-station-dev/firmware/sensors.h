#include <sps30.h>
#include <HTTPClient.h>

#include <OneWire.h>
#include <DallasTemperature.h>

#include <Wire.h>
#include <string.h>
#include <stdlib.h>

#include <esp_adc_cal.h>

#define TEMP   33
#define ANEMOMETRO  35
#define RAINFALL 36

const float pi = 3.14159265;
int ANEM_PERIODO = 5000;
int ANEM_RAIO = 147;

unsigned int anemCont = 0;
unsigned int anemRPM = 0;
float velocVentKMH = 0;
float velocVentMS = 0;

float rainfall_m = 0;

char payload[300];

const char *SSID = "solar2";
const char *PASS = "solar2ufms";

uint8_t MAC_ADDRESS[6] = {0xAC, 0x84, 0xC6, 0xDC, 0x15, 0x2C};

OneWire oneWire(TEMP);
DallasTemperature temp(&oneWire);
RtcDS1307<TwoWire> rtc(Wire);

esp_adc_cal_characteristics_t adc_cal;


void setup_sps30()
{
  s16 ret;
  u8 auto_clean_days = 4;
  u32 auto_clean;

  Serial.begin(9600);
  delay(2000);

  while (sps30_probe() != 0) {
    Serial.print("SPS sensor probing failed\n");
    delay(500);
  }

  ret = sps30_set_fan_auto_cleaning_interval_days(auto_clean_days);
  if (ret) {
    Serial.print("error setting the auto-clean interval: ");
    Serial.println(ret);
  }

  ret = sps30_start_measurement();
  if (ret < 0) {
    Serial.print("error starting measurement\n");
  }

  Serial.print("measurements started\n");
}
void get_particulate(float *particulate_array)
{
  struct sps30_measurement m;
  char serial[SPS_MAX_SERIAL_LEN];
  u16 data_ready;
  s16 ret;

  do {
    ret = sps30_read_data_ready(&data_ready);
    if (ret < 0) {
      Serial.print("error reading data-ready flag: ");
      Serial.println(ret);
    } else if (!data_ready)
      Serial.print("data not ready, no new measurement available\n");
    else
      break;
    delay(100); /* retry in 100ms */
  } while (1);

  ret = sps30_read_measurement(&m);
  if (ret < 0) {
    Serial.print("error reading measurement\n");
  } else {

    *particulate_array = m.mc_1p0;
    *(particulate_array + 1) = m.mc_2p5 - m.mc_1p0;
    *(particulate_array + 2) = m.mc_4p0 - m.mc_2p5;
    *(particulate_array + 3) = m.mc_10p0 - m.mc_4p0;
    *(particulate_array + 4) = m.nc_1p0;
    *(particulate_array + 5) = m.nc_2p5 - m.nc_1p0;
    *(particulate_array + 6) = m.nc_4p0 - m.nc_2p5;
    *(particulate_array + 7) = m.nc_10p0 - m.nc_4p0;
    *(particulate_array + 8) = m.typical_particle_size;

  }

}
float get_temperature()
{
  temp.requestTemperatures();
  delay(100);
  return temp.getTempCByIndex(0);
}
void Contador_Anem()
{
  anemCont++;
}
void Velocidade_Do_Vento()
{
  velocVentKMH = 0;
  velocVentMS = 0;
  anemCont = 0;
  attachInterrupt(digitalPinToInterrupt(35), Contador_Anem, RISING);
  unsigned long millis();
  long startTime = millis();
  while (millis() < startTime + ANEM_PERIODO);
}
void Calcula_RPM()
{
  anemRPM = ((anemCont) * 60) / (ANEM_PERIODO / 1000.0); // Calculate revolutions per minute (RPM)
}

void Velocidade_Do_Vento_MS()
{
  velocVentMS = ((4 * pi * ANEM_RAIO * anemRPM) / 60) / 1000.0; // Calculate wind speed on m/s
}

void Velocidade_Do_Vento_KMH()
{
  velocVentKMH = (((4 * pi * ANEM_RAIO * anemRPM) / 60) / 1000.0) * 3.6; // Calculate wind speed on km/h
  millis();
}

void get_wind_v()
{
  Velocidade_Do_Vento();
  Calcula_RPM();
  Velocidade_Do_Vento_KMH();
}

float get_irr()
{
  uint32_t voltage = 0;
  for (int i = 0; i < 100; i++)
  {
    voltage += adc1_get_raw(ADC1_CHANNEL_4);//Obtem o valor RAW do ADC
    ets_delay_us(30);
  }
  voltage /= 100;


  voltage = esp_adc_cal_raw_to_voltage(voltage, &adc_cal);//Converte e calibra o valor lido (RAW) para mV
  float irr = 1600 * ((((voltage - 10) / 51.1) - 4) / 16);
  if (irr < 0)
    return 0;

  return irr;
}

int get_wind_d()
{
  uint32_t voltage = 0;
  for (int i = 0; i < 100; i++)
  {
    voltage += adc1_get_raw(ADC1_CHANNEL_3);//Obtem o valor RAW do ADC
    ets_delay_us(30);
  }
  voltage /= 100;
  voltage = esp_adc_cal_raw_to_voltage(voltage, &adc_cal);//Converte e calibra o valor lido (RAW) para mV

  if (voltage <= 196)
    return 335;

  else if (voltage <= 225)
    return 270;

  else if (voltage <= 255) 
    return 225;

  else if (voltage <= 298)
    return 180;

  else if (voltage <= 365) 
    return 135;

  else if (voltage <= 460)
    return 90;
     
  else if (voltage <= 700)
    return 45;
  
  else
    return 0;
  
}

bool post_event()
{
  HTTPClient http;

  http.begin("http://172.16.19.0/station");
  http.addHeader("Content-Type", "text/plain");
  http.addHeader("Content-Lenght", String(strlen(payload)));

  int res = http.POST(payload);
  http.end();
  if (res == 200)
    return true;
  else if (WiFi.status() != WL_CONNECTED)
    esp_restart();
  else
    return false;
}

void rainfall_f(void *pvParameters)
{
  for(;;)
  {
    if (digitalRead(RAINFALL) == HIGH)
    { 
      while(digitalRead(RAINFALL) == HIGH);
        vTaskDelay(1);
      vTaskDelay(150/ portTICK_PERIOD_MS);
      rainfall_m += 0.25;
    }
    vTaskDelay(1);
  }
}
